package com.example.gunluk

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.widget.*
import java.security.MessageDigest

class LockActivity : Activity() {
    private lateinit var prefs: android.content.SharedPreferences
    private lateinit var pal: Palette
    private lateinit var input: EditText
    private lateinit var statusText: TextView
    private var firstStepPin: String? = null // PIN oluştururken ilk girilen değeri tutar

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun hash(s: String): String =
        MessageDigest.getInstance("SHA-256").digest(s.toByteArray()).joinToString("") { "%02x".format(it) }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        prefs = getSharedPreferences("gunluk", MODE_PRIVATE)
        pal = Theme.get(this)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(dp(40), 0, dp(40), 0)
            setBackgroundColor(pal.bg)
        }

        val title = TextView(this).apply {
            text = "Günlük"
            textSize = 26f
            setTextColor(pal.text)
            gravity = Gravity.CENTER
        }
        root.addView(title)

        statusText = TextView(this).apply {
            textSize = 14f
            setTextColor(pal.muted)
            gravity = Gravity.CENTER
            setPadding(0, dp(12), 0, dp(28))
        }
        root.addView(statusText)

        input = EditText(this).apply {
            inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_VARIATION_PASSWORD
            textSize = 24f
            gravity = Gravity.CENTER
            setTextColor(pal.text)
            letterSpacing = 0.4f
            filters = arrayOf(android.text.InputFilter.LengthFilter(4))
            val bgD = GradientDrawable()
            bgD.cornerRadius = dp(16).toFloat()
            bgD.setColor(pal.card)
            background = bgD
            setPadding(dp(20), dp(18), dp(20), dp(18))
        }
        root.addView(input)

        val spacer = Space(this); spacer.layoutParams = LinearLayout.LayoutParams(-1, dp(20))
        root.addView(spacer)

        val btn = Button(this).apply {
            text = "Devam"
            isAllCaps = false
            setTextColor(Color.WHITE)
            val bgD = GradientDrawable(); bgD.cornerRadius = dp(16).toFloat(); bgD.setColor(pal.accent)
            background = bgD
            setPadding(dp(24), dp(16), dp(24), dp(16))
            setOnClickListener { onSubmit() }
        }
        root.addView(btn)

        setContentView(root)
        refreshStatus()
    }

    private fun refreshStatus() {
        val hasPin = prefs.getString("pin_hash", null) != null
        statusText.text = if (hasPin) "Devam etmek için 4 haneli PIN'ini gir"
            else if (firstStepPin == null) "Günlüğünü korumak için 4 haneli bir PIN belirle"
            else "Onaylamak için PIN'i tekrar gir"
    }

    private fun onSubmit() {
        val value = input.text.toString()
        if (value.length != 4) {
            Toast.makeText(this, "4 haneli bir PIN gir", Toast.LENGTH_SHORT).show()
            return
        }
        val hasPin = prefs.getString("pin_hash", null) != null

        if (hasPin) {
            val saved = prefs.getString("pin_hash", null)
            if (hash(value) == saved) {
                startActivity(Intent(this, MainActivity::class.java))
                finish()
            } else {
                Toast.makeText(this, "Yanlış PIN", Toast.LENGTH_SHORT).show()
                input.text.clear()
            }
        } else {
            if (firstStepPin == null) {
                firstStepPin = value
                input.text.clear()
                refreshStatus()
            } else {
                if (firstStepPin == value) {
                    prefs.edit().putString("pin_hash", hash(value)).apply()
                    startActivity(Intent(this, MainActivity::class.java))
                    finish()
                } else {
                    Toast.makeText(this, "PIN'ler uyuşmadı, tekrar dene", Toast.LENGTH_SHORT).show()
                    firstStepPin = null
                    input.text.clear()
                    refreshStatus()
                }
            }
        }
    }
}
